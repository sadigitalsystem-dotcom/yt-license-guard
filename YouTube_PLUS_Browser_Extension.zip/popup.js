document.addEventListener('DOMContentLoaded', () => {
  const keyDisplay = document.getElementById('key-display');
  const expDisplay = document.getElementById('exp-display');
  const rekeyBtn = document.getElementById('rekey-btn');

  chrome.storage.local.get(['yt_plus_key', 'yt_plus_license'], (res) => {
    if (res.yt_plus_key) {
      keyDisplay.textContent = res.yt_plus_key;
    }
    if (res.yt_plus_license && res.yt_plus_license.expiry_date) {
      const expDate = new Date(res.yt_plus_license.expiry_date);
      expDisplay.textContent = expDate.toLocaleDateString('ar-SA') || expDate.toISOString().split('T')[0];
    }
  });

  rekeyBtn.addEventListener('click', () => {
    chrome.storage.local.remove(['yt_plus_key', 'yt_plus_license'], () => {
      alert('تم حذف المفتاح. يرجى تحديث صفحة يوتيوب لإدخال المفتاح الجديد.');
      window.close();
    });
  });
});
